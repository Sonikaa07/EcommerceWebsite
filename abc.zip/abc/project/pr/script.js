let currentSlideIndex = 0;
let slides = document.querySelectorAll('.slide');
let dots = document.querySelectorAll('.dot');

// Show the current slide based on the index
function showSlide(index) {
    if (index >= slides.length) {
        currentSlideIndex = 0; // Loop back to the first slide
    } else if (index < 0) {
        currentSlideIndex = slides.length - 1; // Loop to the last slide
    } else {
        currentSlideIndex = index;
    }

    const slideWidth = slides[0].clientWidth;
    document.querySelector('.slider').style.transform = `translateX(${-slideWidth * currentSlideIndex}px)`;

    // Update the dots
    dots.forEach(dot => dot.classList.remove('active'));
    dots[currentSlideIndex].classList.add('active');
}

// Move to the next slide
function nextSlide() {
    showSlide(currentSlideIndex + 1);
}

// Move to the previous slide
function prevSlide() {
    showSlide(currentSlideIndex - 1);
}

// Set the slide based on dot click
function currentSlide(index) {
    showSlide(index);
}

// Automatic sliding
function startAutoSlide() {
    return setInterval(nextSlide, 3000); // Slide change every 3 seconds
}

// Start the slideshow and auto-slide
let slideInterval = startAutoSlide();

// Add event listeners for navigation buttons and dots
document.querySelector('.next').addEventListener('click', function() {
    nextSlide();
    resetAutoSlide();
});

document.querySelector('.prev').addEventListener('click', function() {
    prevSlide();
    resetAutoSlide();
});

dots.forEach((dot, index) => {
    dot.addEventListener('click', function() {
        currentSlide(index);
        resetAutoSlide();
    });
});

// Reset the auto-slide timer whenever manual navigation is used
function resetAutoSlide() {
    clearInterval(slideInterval);
    slideInterval = startAutoSlide();
}

// Initialize the slider by showing the first slide
window.onload = function() {
    showSlide(currentSlideIndex);
};
