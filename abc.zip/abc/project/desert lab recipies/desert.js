 const p
 rintbtn=document.getElementsByClassName('main');
 printbtn.addEventListner('click',function(){
    print();
 })